<?php
require_once 'database-connect.php';
require_once 'Question.php';

function post_question($question) {
    global $pdo;

    $query = "INSERT INTO question (enonce, reponse, answer) VALUES (?, ?, ?)";
    $stmt = $pdo->prepare($query);
    $stmt->bindValue(1, $question->getEnonce(), PDO::PARAM_STR);
    $stmt->bindValue(2, $question->getReponses(), PDO::PARAM_STR);
    $stmt->bindValue(3, $question->getAnswer(), PDO::PARAM_INT);

    return $stmt->execute();
}


function get_question($enonce) {
    global $pdo;

    $query = "SELECT * FROM questions WHERE enonce = :enonce LIMIT 1";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':enonce', $enonce);
    $stmt->execute();

    $data = $stmt->fetch();

    if ($data) {
        return new Question($data['enonce'], $data['reponses'], $data['answer']);
    }
    return null; 
}


function get_questions() {
    global $pdo;

    $query = "SELECT * FROM questions";
    $stmt = $pdo->query($query);

    $questions = [];
    while ($data = $stmt->fetch()) {
        $questions[] = new Question($data['enonce'], $data['reponses'], $data['answer']);
    }

    return $questions;
}
?>