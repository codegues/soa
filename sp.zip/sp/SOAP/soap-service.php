<?php
require_once 'nusoap.php';
require_once 'database-service.php';

$wsdl = "http://localhost/soap/soap-service.php?wsdl";

$server = new soap_server();
$server->configureWSDL("soap service","http://localhost/soap/soap-service.php");
$server->register(
    'insert_quest', 
    array(  
        'enonce' => 'xsd:string',  // enonce is a string
        'reponses' => 'xsd:string',  // reponses is a string
        'answer' => 'xsd:int'  // answer is an integer
    ),
    array(  
        'result' => 'xsd:string'  // result is a string (success or failure)
    ),
    "http://localhost/soap/soap-service.php",
    false,
    'rpc', 
    'encoded', 
    'Insert a new question'
);


$server->register(
    'get_quest',  
    array( 
        'enonce' => 'xsd:string'  
    ),
    array(  
        'result' => 'xsd:string'  
    ),
    "http://localhost/soap/soap-service.php",
    false,
    'rpc', 
    'encoded', 
    'Get a specific question',    
);

$server->register(
    'add',  
    array('a' =>'xsd:int',
             'b' => 'xsd:int'),  
    array(  
        'result' => 'xsd:int'  
    ),
    "http://localhost/soap/soap-service.php",
    false,
    'rpc', 
    'encoded', 
    'Get all questions',  
);

$server->register(
    'get_quests',  
    array(),  
    array(  
        'result' => 'xsd:Array'  
    ),
    "http://localhost/soap/soap-service.php",
    false,
    'rpc', 
    'encoded', 
    'Get all questions',  
);
function add($a, $b){
    return $a+$b;
}
function get_quests() {
    return get_questions();
}
function get_quest($enonce) {
    return get_question($enonce);
}
function insert_quest($enonce, $reponses, $answer) {
    $quest = new Question($enonce, $reponses, $answer);
    $success = post_question($quest);
    if ($success) { return "success";}else{ return "failed!";}
}
function delete_quest($enonce) {
}



$HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA :"";
$server -> service($HTTP_RAW_POST_DATA);
?>